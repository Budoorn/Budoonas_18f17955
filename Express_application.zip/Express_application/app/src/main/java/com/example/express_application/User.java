package com.example.express_application;


public class User {

    private String name;
    private String com1;

    public User() {
    }

    public User(String name, String com1) {
        this.name = name;
        this.com1 = com1;
    }

    public String getName() {
        return name;
    }

    public String getCom1() {
        return com1;
    }

    public void setComment(String string) {
    }

    public void setName(String toString) {
    }
}


